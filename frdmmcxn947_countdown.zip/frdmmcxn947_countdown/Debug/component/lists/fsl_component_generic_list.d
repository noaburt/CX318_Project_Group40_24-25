component/lists/fsl_component_generic_list.o \
 component/lists/fsl_component_generic_list.d: \
 ../component/lists/fsl_component_generic_list.c \
 ../component/lists/fsl_component_generic_list.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/fsl_device_registers.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/system_MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0_features.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common_arm.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_clock.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_reset.h
../component/lists/fsl_component_generic_list.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/fsl_device_registers.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/system_MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0_features.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common_arm.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_clock.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_reset.h:
