drivers/fsl_lpi2c.o drivers/fsl_lpi2c.d: ../drivers/fsl_lpi2c.c \
 ../drivers/fsl_lpi2c.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/fsl_device_registers.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/system_MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0_features.h \
 ../drivers/fsl_common.h ../drivers/fsl_common_arm.h \
 ../drivers/fsl_clock.h ../drivers/fsl_reset.h \
 ../drivers/fsl_lpflexcomm.h
../drivers/fsl_lpi2c.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/fsl_device_registers.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/system_MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0_features.h:
../drivers/fsl_common.h:
../drivers/fsl_common_arm.h:
../drivers/fsl_clock.h:
../drivers/fsl_reset.h:
../drivers/fsl_lpflexcomm.h:
