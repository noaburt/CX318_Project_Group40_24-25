source/shield_oled.o source/shield_oled.d: ../source/shield_oled.c \
 ../source/shield_oled.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/fsl_device_registers.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/system_MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0_features.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common_arm.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_clock.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_reset.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_lpi2c.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_lpflexcomm.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\board/board.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\board/clock_config.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_gpio.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\board/peripherals.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\utilities/fsl_debug_console.h
../source/shield_oled.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/fsl_device_registers.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/system_MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0_features.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common_arm.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_clock.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_common.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_reset.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_lpi2c.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_lpflexcomm.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\board/board.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\board/clock_config.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\drivers/fsl_gpio.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\board/peripherals.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\device/MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\utilities/fsl_debug_console.h:
