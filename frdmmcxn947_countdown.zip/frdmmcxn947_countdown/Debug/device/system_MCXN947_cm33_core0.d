device/system_MCXN947_cm33_core0.o device/system_MCXN947_cm33_core0.d: \
 ../device/system_MCXN947_cm33_core0.c ../device/fsl_device_registers.h \
 ../device/MCXN947_cm33_core0.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h \
 C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h \
 ../device/system_MCXN947_cm33_core0.h \
 ../device/MCXN947_cm33_core0_features.h
../device/fsl_device_registers.h:
../device/MCXN947_cm33_core0.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/core_cm33.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_version.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_compiler.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/cmsis_gcc.h:
C:\Users\princ\Documents\MCUXWorkspace\frdmmcxn947_hello_world_demo\CMSIS/mpu_armv8.h:
../device/system_MCXN947_cm33_core0.h:
../device/MCXN947_cm33_core0_features.h:
